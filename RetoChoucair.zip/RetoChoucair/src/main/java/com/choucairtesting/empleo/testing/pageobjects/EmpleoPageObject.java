package com.choucairtesting.empleo.testing.pageobjects;

import static org.junit.Assert.assertThat;

import org.hamcrest.Matchers;
import org.openqa.selenium.By;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.DefaultUrl;

@DefaultUrl("https://www.choucairtesting.com/")

public class EmpleoPageObject extends PageObject {

	//Localizadores
	By empleoLink =  By.xpath("//a[@href=\"https://www.choucairtesting.com/empleos-testing/\"]");
	By palabraTxt = By.id("search_keywords");
	By localizacionTxt = By.id("search_location");
	By submitBtn = By.xpath("//input[@type=\"submit\"]");
	By practicanteTxt = By.xpath("//*[contains(text(),'Apoyar el proceso de internacional')]");
	By practicanteLink = By.xpath("//a[@href=\"https://www.choucairtesting.com/job/practicante-de-mercadeo-enfoque-internacional/\"]");
	By analistaPanamaTxt = By.xpath("//h1[contains(text(),'Analista de Pruebas Panam')]");
	By analistaPanamaLink = By.xpath("//a[@href=\"https://www.choucairtesting.com/job/analista-de-pruebas-panama/\"]");
	By panamaTxt = By.xpath("//a[@class=\"google_map_link\"]");
	By alertaTxt = By.xpath("//li[@class='no_job_listings_found']");
	
	//Metodos
	
	public void irAEmpleo() {
		getDriver().findElement(empleoLink).click();
	}
	
	public void escribirPalabra(String palabra) {
		getDriver().findElement(palabraTxt).sendKeys(palabra);	
	}
	
	public void escribirLocalizacion(String localizacion) {
		getDriver().findElement(localizacionTxt).sendKeys(localizacion);
	}
	
	public void clickBuscar() {
		getDriver().findElement(submitBtn).click();
	}	
	
	public void irPracticante() {
		getDriver().findElement(practicanteLink).click();
	}
	
	public void confirmarPracticante() {
		assertThat(getDriver().findElement(practicanteTxt).isDisplayed(), Matchers.is(true));
	}
	
	public void irAnalista() {
		getDriver().findElement(analistaPanamaLink).click();
	}
	
	public void confirmarCargo() {
		assertThat(getDriver().findElement(analistaPanamaTxt).isDisplayed(), Matchers.is(true));
		
	}
	
	public void confirmarPais() {
		assertThat(getDriver().findElement(panamaTxt).isDisplayed(), Matchers.is(true));
	}
	
	public void confirmarAlerta() {
		assertThat(getDriver().findElement(alertaTxt).isDisplayed(), Matchers.is(true));
	}
	
}
