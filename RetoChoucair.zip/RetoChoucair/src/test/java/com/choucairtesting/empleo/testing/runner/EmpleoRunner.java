package com.choucairtesting.empleo.testing.runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.SnippetType;
import net.serenitybdd.cucumber.CucumberWithSerenity;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(features="src/test/resources/com/choucairtesting/empleo/testing/features/Empleo.feature",
glue="com.choucairtesting.empleo.testing.stepdefinitions",
snippets=SnippetType.CAMELCASE)

public class EmpleoRunner {

}
