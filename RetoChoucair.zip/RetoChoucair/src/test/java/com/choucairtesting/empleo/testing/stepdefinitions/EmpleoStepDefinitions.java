package com.choucairtesting.empleo.testing.stepdefinitions;

import java.util.List;

import com.choucairtesting.empleo.testing.models.Empleo;
import com.choucairtesting.empleo.testing.steps.EmpleoSteps;

import cucumber.api.java.es.Cuando;
import cucumber.api.java.es.Dado;
import cucumber.api.java.es.Entonces;
import net.thucydides.core.annotations.Steps;

public class EmpleoStepDefinitions {
	
	@Steps
	EmpleoSteps empleoSteps;

	@Dado("^que estoy en la seccion de empleos$")
	public void queEstoyEnLaSeccionDeEmpleos() {
	   empleoSteps.abrirApp();
	   empleoSteps.irAEmpleo();
	}


	@Cuando("^ingreso los datos por palabra y selecciono$")
	public void ingresoLosDatosPorPalabraYSelecciono(List<Empleo> listaEmpleo) {
		empleoSteps.escribirPalabra(listaEmpleo.get(0).getPalabra());
		empleoSteps.clickBuscar();
		empleoSteps.irPracticante();
	  
	}

	@Entonces("^valido el texto \"([^\"]*)\"$")
	public void validoElTexto(String arg1) {
	    empleoSteps.confirmarPracticante();
	}

	@Cuando("^ingreso los datos por localizacion y palabra y selecciono$")
	public void ingresoLosDatosPorLocalizacionYPalabraYSelecciono(List<Empleo> listaEmpleo) {
		empleoSteps.escribirPalabra(listaEmpleo.get(0).getPalabra());
		empleoSteps.escribirLocalizacion(listaEmpleo.get(0).getLocalizacion());
		empleoSteps.clickBuscar();
		empleoSteps.irAnalista();
		
	}

	@Entonces("^valido el cargo \"([^\"]*)\"$")
	public void validoElCargo(String arg1) {
	    empleoSteps.confirmarCargo();
	}

	@Entonces("^valido el pais \"([^\"]*)\"$")
	public void validoElPais(String arg1) {
	   empleoSteps.confirmarPais();
	}
	
	@Cuando("^ingreso los datos por localizacion y palabra inexistente$")
	public void ingresoLosDatosPorLocalizacionYPalabraInexistente(List<Empleo> listaEmpleo) {
		empleoSteps.escribirPalabra(listaEmpleo.get(0).getPalabra());
		empleoSteps.escribirLocalizacion(listaEmpleo.get(0).getLocalizacion());
		empleoSteps.clickBuscar();
	}

	@Entonces("^valido la alerta \"([^\"]*)\"$")
	public void validoLaAlerta(String arg1) {
	    empleoSteps.confirmarAlerta();
	} 
	
}
